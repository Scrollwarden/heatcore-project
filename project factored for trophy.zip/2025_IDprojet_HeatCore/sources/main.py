"""
Projet : HeatCore
Auteurs : Lou Schanen, Matthew Batt, Cosmo Pinot, Gaspard Dupin (équipe PP42)
"""

import os
import sys
import subprocess

SCRIPT = "engine.engine_main"

base_dir = os.path.dirname(os.path.abspath(__file__))
os.chdir(base_dir)
subprocess.run([sys.executable, "-m", SCRIPT])
