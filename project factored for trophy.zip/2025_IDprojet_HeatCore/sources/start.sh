#!/bin/bash
cd "$(dirname "$0")"
python3 -m engine.engine_main
